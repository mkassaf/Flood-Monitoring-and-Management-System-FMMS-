"""Entry point for the dashboard-bff service."""

import uvicorn

from dashboard_bff.api import app
from dashboard_bff.config import settings


def main() -> None:
    uvicorn.run(
        app,
        host="0.0.0.0",  # noqa: S104 — container binds to all interfaces by design
        port=8000,
        log_level=settings.log_level.lower(),
    )


if __name__ == "__main__":
    main()
