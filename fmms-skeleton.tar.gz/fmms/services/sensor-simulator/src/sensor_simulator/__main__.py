"""Entry point for the sensor-simulator worker. Phase 3+ wires the actual consumers."""

import asyncio
import logging

import uvicorn

from sensor_simulator.api import app
from sensor_simulator.config import settings


async def run_worker() -> None:
    """Placeholder — Phase 3+ replaces this with the real consumer loop."""
    logging.info("sensor-simulator worker starting (placeholder)")
    while True:
        await asyncio.sleep(60)


async def run_metrics_server() -> None:
    config = uvicorn.Config(app, host="0.0.0.0", port=8000, log_level=settings.log_level.lower())  # noqa: S104
    server = uvicorn.Server(config)
    await server.serve()


async def main() -> None:
    await asyncio.gather(run_worker(), run_metrics_server())


if __name__ == "__main__":
    asyncio.run(main())
