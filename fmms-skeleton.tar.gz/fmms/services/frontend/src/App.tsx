// Phase 3+ replaces this with the real role-conditional dashboard.
// See services/frontend/README.md for the layout map.

export default function App() {
  return (
    <div style={{ padding: "2rem", fontFamily: "system-ui" }}>
      <h1>FMMS</h1>
      <p>Flood Monitoring and Management System — frontend scaffold.</p>
      <p>Phase 3+ wires the map, alert list, and WebSocket client.</p>
    </div>
  );
}
